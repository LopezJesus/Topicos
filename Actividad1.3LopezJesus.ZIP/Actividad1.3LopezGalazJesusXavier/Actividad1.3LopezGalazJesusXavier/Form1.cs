﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad1._3LopezGalazJesusXavier
{
    public partial class frmNomina : Form
    {
        public frmNomina()
        {
            InitializeComponent();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnRealizar_Click(object sender, EventArgs e)
        {
            string Nomb;
            int Salario, Hora;
            var HoraDelDia = DateTime.Now.ToShortTimeString();
            var Fecha = DateTime.Now.ToString("dd/MMMM/yyy");

            Nomb = txtEmpleado.Text;
            Salario = int.Parse(txtSalario.Text);
            Hora = int.Parse(txtHora.Text);

            int SalarioMensual = (Salario * Hora);

            if (SalarioMensual < 4000)
            {
                MessageBox.Show(HoraDelDia + "\n" + Fecha+ "\n \nAdvertencia, usted esta por debajo del salario minimo. "+ "\nNombre del empleado: " 
                    +Nomb + "\nSalario Mensual: " +SalarioMensual  , "Nomina ADVERTENCIA");

            }
            else
            {
                MessageBox.Show(HoraDelDia + "\n" + Fecha + "\n \nNombre del empleado: " + Nomb, "Nomina ");

            }


        }
    }
}
